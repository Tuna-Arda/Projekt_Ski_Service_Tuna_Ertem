document.getElementById('serviceForm').addEventListener('submit', async function (e) 
{
    e.preventDefault();

    if (!this.checkValidity()) 
        {
        this.classList.add('was-validated');
        return;
    }

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const priority = document.getElementById('priority').value;
    const service = document.getElementById('service').value;

    const data = {
        name,
        email,
        phone,
        priority,
        service,
        create_date: new Date().toISOString(),
    };

    try {
        const response = await fetch('http://localhost:5000/api/registration', 
            {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });

        if (response.ok) 
            {
            alert('Serviceanmeldung erfolgreich!');
            this.reset();
            this.classList.remove('was-validated');
        } else 
        {
            alert('Fehler bei der Anmeldung. Bitte versuchen Sie es nochmal.');
        }
    } catch (error) 
    {
        console.error('Fehler:', error);
        alert('Serververbindung fehlgeschlagen.');
    }
    
    const userRouter = require("./routes/user.route");

    // Benutzer-Routen einbinden
    app.use("/api/users", userRouter);


    document.getElementById('priority').addEventListener('change', async (e) => {
        const priority = e.target.value;
    
        try {
            const response = await fetch('http://localhost:5000/api/calculate-pickup-date', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ priority })
            });
    
            const data = await response.json();
            document.getElementById('pickupDate').value = data.pickupDate;
        } catch (err) {
            console.error("Fehler beim Abrufen des Abholdatums:", err);
        }
    });


    document.getElementById('serviceForm').addEventListener('submit', (e) => {
        e.preventDefault();
    
        const pickupTime = document.getElementById('pickupTime').value;
    
        if (!pickupTime) {
            alert("Bitte eine Abholzeit eingeben.");
            return;
        }
    
        
    });
    
    

    

});
