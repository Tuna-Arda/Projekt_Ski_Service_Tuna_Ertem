const fs = require("fs");
const path = require("path");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const userFilePath = path.join(__dirname, "../data/users.json");

const loadUsers = () => {
    if (!fs.existsSync(userFilePath)) {
        fs.writeFileSync(userFilePath, JSON.stringify([]));
    }
    return JSON.parse(fs.readFileSync(userFilePath, "utf-8"));
};

const saveUsers = (users) => {
    fs.writeFileSync(userFilePath, JSON.stringify(users, null, 2));
};

// Benutzerregistrierung
exports.registerUser = async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ error: "Alle Felder sind erforderlich." });
    }

    const users = loadUsers();
    const userExists = users.find(user => user.email === email);

    if (userExists) {
        return res.status(400).json({ error: "Benutzer existiert bereits." });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = {
        id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
        name,
        email,
        password: hashedPassword
    };

    users.push(newUser);
    saveUsers(users);

    res.status(201).json({ message: "Benutzer erfolgreich registriert." });
};

// Benutzeranmeldung
exports.loginUser = async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: "E-Mail und Passwort sind erforderlich." });
    }

    const users = loadUsers();
    const user = users.find(u => u.email === email);

    if (!user) {
        return res.status(400).json({ error: "Benutzer nicht gefunden." });
    }

    const passwordValid = await bcrypt.compare(password, user.password);
    if (!passwordValid) {
        return res.status(401).json({ error: "Ungültiges Passwort." });
    }

    const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: "1h" });
    res.status(200).json({ message: "Login erfolgreich.", token });
};
