'use strict';
const fs = require("fs");

var registration_data = [];

// Funktion zum Laden der Registrierungen aus der JSON-Datei
const getRegistrationData = () => {
    try {
        registration_data = loadData();
        return registration_data;
    } catch (err) {
        throw err;
    }
};

// Funktion zum Speichern einer neuen Registrierung
const saveRegistrationData = (data) => {
    try {
        // Lade bestehende Daten aus der JSON-Datei
        registration_data = loadData();

        const createDate = new Date().toISOString(); // Erstellungsdatum
        let pickupDate = calculatePickupDate(data.priority, createDate); // Abholdatum berechnen

        // Benutzerdefinierte Uhrzeit übernehmen
        if (data.pickupTime) {
            const [hours, minutes] = data.pickupTime.split(":");
            let pickupDateObject = new Date(pickupDate);
            pickupDateObject.setHours(parseInt(hours), parseInt(minutes), 0, 0);
            pickupDate = pickupDateObject.toISOString();
        }

        const addEntry = {
            id: registration_data.length > 0
                ? Math.max(...registration_data.map(o => o.id)) + 1
                : 1,
            name: data.name,
            email: data.email,
            phone: data.phone,
            priority: data.priority,
            service: data.service,
            create_date: createDate,
            pickup_date: pickupDate
        };

        // Neue Registrierung hinzufügen
        registration_data.push(addEntry);

        // Daten in die JSON-Datei speichern
        saveData(registration_data);

        return addEntry;

    } catch (err) {
        throw err;
    }
};

// Funktion zum Löschen einer Registrierung
const deleteRegistrationData = (id) => {
    try {
        // Lade bestehende Daten aus der JSON-Datei
        registration_data = loadData();

        let registrationId = parseInt(id);

        // Registrierung finden
        const delete_entry = registration_data.find(elem => elem.id === registrationId);

        if (delete_entry) {
            // Registrierung löschen
            registration_data = registration_data.filter(elem => elem.id != registrationId);

            // Daten in die JSON-Datei speichern
            saveData(registration_data);
        }

        return delete_entry;
    } catch (err) {
        throw err;
    }
};

// Funktion zum Laden der Daten aus der JSON-Datei
const loadData = () => {
    const data_file = __dirname + "\\" + process.env.REGISTRATION_DATA_FILE || "";
    return JSON.parse(fs.readFileSync(data_file, 'utf-8'));
};

// Funktion zum Speichern der Daten in der JSON-Datei
const saveData = (data) => {
    const data_file = __dirname + "\\" + process.env.REGISTRATION_DATA_FILE || "";
    fs.writeFileSync(data_file, JSON.stringify(data, null, 2), 'utf8');
};

// Funktion zur Berechnung des Abholdatums basierend auf der Priorität
const calculatePickupDate = (priority, createDate) => {
    const daysToAdd = { "Tief": 5, "Standard": 0, "Express": -2 }[priority];
    let pickupDate = new Date(createDate);

    let addedDays = 0;
    while (addedDays < 7 + daysToAdd) { // Maximale Dauer: 7 + zusätzliche Tage
        pickupDate.setDate(pickupDate.getDate() + 1);

        // Ignoriere Wochenendtage
        if (pickupDate.getDay() !== 0 && pickupDate.getDay() !== 6) {
            addedDays++;
        }
    }

    return pickupDate.toISOString();
};

// Export der Funktionen
module.exports = {
    getRegistrationData: getRegistrationData,
    saveRegistrationData: saveRegistrationData,
    deleteRegistrationData: deleteRegistrationData,
    registration_data: registration_data
};
